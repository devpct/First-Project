#include <iostream>
#include <windows.h>

using namespace std;
 
//variables

		char nut1 = 'X' , nut2 = 'O';
	
	string spaces0 = "  " , spaces1 = "     " , spaces2 = "                               ",
	 spaces3 = "                          " , spaces4 = "                                           " ,
	 				spaces5 = "                       " ,
	 				
	 				 underline = "_____" ,
				smoothline1 = "|" , smoothline2 = "  |  " ;

	int number [9] = {1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9}; 

	int range_counter1 = 0 , range_counter2 = 0 ;
	
	int restart_number = 3 ;
	
	int number_rnd = 0 ;
	
	int rnd_restart = 0 ;
	
	string message = spaces2 + spaces3 + "Your turn is over" ; int text_time = 3 ;
	
	int rnd = 0 ;
	
	int rnd_bot = 0 ;
	
	int rnd_bet14 = 0 ;
	
	string name_player1 , name_player2 ;

	char yes_no ;

	int rnd2 = 0 ;
	
	int error_spaces = 0 ;
	
	int error_spaces1 = 0 ;

	bool bet0 = true , bet1 = true , bet2 = true , bet3 = true , bet4 = true , bet5 = true ,
	bet6 = true , bet7 = true , bet8 = true ;		
		 
	bool bet9 = true , bet10 = true , bet11 = true , bet12 = true , bet13 = true , bet14 = true ,
	bet15 = true , bet16 = true , bet17 = true , bet18 = true , bet19 = true , bet20 = true ,
	bet21 = true , bet22 = true , bet23 = true , bet24 = true , bet25 = true , bet26 = true , bet27 = true ,
	bet28 = true , bet29 = true , bet30 = true , bet31 = true  , bet32 = true;
	
	bool number1 = true , number2 = true , number3 = true , number4 = true , number5 = true ,
	number6 = true , number7 = true , number8 = true , number9 = true ;
	
	int game_selection ;
	
	int level_selection ;
	
//functions

//color
	int setConsoleColor(WORD c) {SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),c);}
	
//beat
	int beat1 (){
		for (int i=0 ; i < 2 ; i++){
   		 Beep(1568, 200);
   		 Beep(1568, 200);
   		 Beep(1568, 200);
   		 Beep(1245, 1000);
  	 	 Beep(1397, 200);
  		 Beep(1397, 200);
   		 Beep(1397, 200);
   		 Beep(1175, 1000);}
	}
	
	int beat2 (){
		for (int i=0 ; i < 2 ; i++){
		 Beep(1397, 200);
		 Beep(1397, 200);
    	 Beep(1175, 1000);
     	 Beep(1397, 200);
    	 Beep(1568, 200);
    	 Beep(1568, 200);
    	 Beep(1568, 200);
    	 Beep(1245, 1000);}
	}
	
//slide one
	void slide_one (){
		system("color 02");
		cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
		spaces2 + spaces0 ;
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout<<" Tic Tac Toe \n\n\n\n";
		setConsoleColor(7);
		cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
		cout<<"  Hello,"; usleep(290000); 
		cout <<"welcome,";usleep(290000);
		cout <<"please choose "; usleep(290000);
		cout <<"your name \n\n\n\n";
		setConsoleColor(7);
		cout<<spaces3 ;
	}

//First player name	
 	void nam1 (){
 		cout<<" Name Player 1 ( X ) : ";
			getline(cin,name_player1);
			
		while(bet0 == true || bet1 == true || bet2 == true || bet3 == true){
 			
 			for (int i = 0 ; i < name_player1.size() ; i++){
			
		if (name_player1[i] >= 'A' && name_player1[i] <= 'Z' || name_player1[i] >= 'a' || name_player1[i] >= 'z'  ||
			  name_player1[i] == ' '){bet0 = false;}
	
		else{
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Please use letters for your name !"; sleep(2);
			setConsoleColor(7);
			bet0 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			nam1();}
			
		if (name_player1[i] == ' '){error_spaces++;}
		}
		
		if (error_spaces > 1){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet1 = true;
			error_spaces = error_spaces - error_spaces ;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			nam1();}	
		else{bet1 = false; error_spaces = error_spaces - error_spaces ;}
		
		if (name_player1.length() <= 2){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet2 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			nam1();}
		else{bet2 = false;}
				
		if(name_player1.length() > 16){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet3 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			nam1();}
		else{bet3 = false;}
		}
			
			cout<<"\n\n\n" + spaces3;
		 }
		 
		 
//Second player name	 
	void nam2 (){
		cout<<" Name Player 2 ( O ) : ";
		getline(cin,name_player2);
			
		while(bet4 == true || bet5 == true || bet6 == true || bet7 == true || bet8 == true){
 			
 		if (name_player2 == name_player1){
			cout<<"\n\n" + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout << "Your name is similar to the name of the first player !";
			setConsoleColor(7);
			sleep(4); bet4 = true ;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
				cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			cout<<" Name Player 1 ( X ) : " << name_player1;
			cout<<"\n\n\n\n" + spaces3 ;
			nam2();}
			else{bet4 = false;}

 			for (int i = 0 ; i < name_player2.size() ; i++){
			
		if (name_player2[i] >= 'A' && name_player2[i] <= 'Z' || name_player2[i] >= 'a' || name_player2[i] >= 'z'  ||
			  name_player2[i] == ' '){bet5 = false;}
	
		else{
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Please use letters for your name !"; sleep(2);
			setConsoleColor(7);
			bet5 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			cout<<" Name Player 1 ( X ) : " << name_player1;
			cout<<"\n\n\n\n" + spaces3 ;
			nam2();}
			
		if (name_player2[i] == ' '){error_spaces++;}
		}
		
		if (error_spaces > 1){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet6 = true;
			error_spaces = error_spaces - error_spaces ;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			cout<<" Name Player 1 ( X ) : " << name_player1;
			cout<<"\n\n\n\n" + spaces3 ;
			nam2();}	
		else{bet6 = false; error_spaces = error_spaces - error_spaces ;}
		
		if (name_player2.length() <= 2){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet7 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			cout<<" Name Player 1 ( X ) : " << name_player1;
			cout<<"\n\n\n\n" + spaces3 ;
			nam2();}
			else{bet7 = false;}
				
		if(name_player2.length() > 16){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet8 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			cout<<spaces3 ;
			cout<<" Name Player 1 ( X ) : " << name_player1;
			cout<<"\n\n\n\n" + spaces3 ;
			nam2();}
		else{bet8 = false;}
		}
	}

//line
	void line(){
		cout<<"\n\n\n  ___________________________________________________________________________";
		sleep(1);
		system("cls");
	}


//Tic Tac Toe table
	void table (){
		system("color 0F");
	
		cout<<"\n\n";
	
		cout<< spaces2 + spaces0 ;
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout<< " Tic Tac Toe \n\n\n";
		setConsoleColor(7);
		cout<< spaces1 + spaces0  << name_player1 + spaces4 + spaces0 << name_player2 + "\n\n"
		<< spaces1 + "player 1 ( X )" + spaces3 + spaces1 + spaces1 + " player 2 ( O ) " + "\n\n"
		<< spaces0 + "Player Win Counter 1 = " << range_counter1	
		<< spaces3 + "Player Win Counter 2 = " << range_counter2 << "\n" 
		<< spaces2+ spaces1 + smoothline1 + spaces1 + "|\n"
		<< spaces2+ spaces0 ;
	}

//number 1 in the table
	void num1 (){
		if(bet14 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[0]);
		setConsoleColor(7); bet32 = false;}
		
		if(bet18 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[0]);
		setConsoleColor(7);bet32 = false;}

		if(bet21 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[0]);
		setConsoleColor(7);bet32 = false;}

		if(bet23 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[0]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet26 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[0]);
		setConsoleColor(7);bet32 = false;}

		if(bet29 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[0]);
		setConsoleColor(7);bet32 = false;}
								
		if (number[0] == 1){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
		cout <<number[0];
			setConsoleColor(7);}
				
			if(bet16 == true){if (number[0] != 1){cout << char(number[0]);}}
			if(bet14 == false){if(bet14 == true){if (number[0] != 1){cout << char(number[0]);}}}
			if(bet21 == false){if(bet21 == true){if (number[0] != 1){cout << char(number[0]);}}}
			if(bet23 == false){if(bet23 == true){if (number[0] != 1){cout << char(number[0]);}}}
			if(bet26 == false){if(bet26 == true){if (number[0] != 1){cout << char(number[0]);}}}			
			if(bet29 == false){if(bet29 == true){if (number[0] != 1){cout << char(number[0]);}}}
		                   
		if (bet14 == true && bet21 == true && bet23 == true && bet26 == true && bet29 == true){
				if(bet16 == false){if (number[0] != 1){cout << char(number[0]);}}
			}
			
				if(bet26 == false){rnd_bet14++;} if(bet29 == false){rnd_bet14++;} 		
		cout << smoothline2 ;
	}

		
//number 2 in the table
	void num2 (){
		if(bet15 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[1]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet18 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[1]);
		setConsoleColor(7);bet32 = false;}

		if(bet24 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[1]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet26 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[1]);
		setConsoleColor(7);bet32 = false;}
				
		if (number[1] == 2){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
		cout <<number[1];
			setConsoleColor(7);bet32 = false;}
				
			if(bet16 == true){if (number[1] != 2){cout << char(number[1]);}}
			if(bet15 == false){if(bet15 == true){if (number[1] != 2){cout << char(number[1]);}}}
			if(bet18 == false){if(bet18 == true){if (number[1] != 2){cout << char(number[1]);}}}
			if(bet24 == false){if(bet24 == true){if (number[1] != 2){cout << char(number[1]);}}}
			if(bet26 == false){if(bet26 == true){if (number[1] != 2){cout << char(number[1]);}}}
			
			if (bet15 == true && bet18 == true && bet24 == true && bet26 == true){
				if(bet16 == false){if (number[1] != 2){cout << char(number[1]);}}
			}
															
		if(bet15 == false){rnd_bet14++;} if(bet24 == false){rnd_bet14++;}
		
			cout << smoothline2 ;
	}


//number 3 in the table
	void num3 (){
		if(bet17 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[2]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet18 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[2]);
		setConsoleColor(7);bet32 = false;}

		if(bet22 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[2]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet25 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[2]);
		setConsoleColor(7);bet32 = false;}

		if(bet26 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[2]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet30 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[2]);
		setConsoleColor(7);bet32 = false;}
		
		if (number[2] == 3){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[2] ; 
			setConsoleColor(7);}
			
			if(bet16 == true){if (number[2] != 3){cout << char(number[2]);}}
			if(bet17 == false){if(bet17 == true){if (number[2] != 3){cout << char(number[2]);}}}
			if(bet18 == false){if(bet18 == true){if (number[2] != 3){cout << char(number[2]);}}}
			if(bet22 == false){if(bet22 == true){if (number[2] != 3){cout << char(number[2]);}}}
			if(bet25 == false){if(bet25 == true){if (number[2] != 3){cout << char(number[2]);}}}
			if(bet26 == false){if(bet26 == true){if (number[2] != 3){cout << char(number[2]);}}}
			if(bet30 == false){if(bet30 == true){if (number[2] != 3){cout << char(number[2]);}}}
			 				
			if (bet17 == true && bet18 == true && bet22 == true && bet25 == true && bet26 == true && bet30 == true){
				if(bet16 == false){if (number[2] != 3){cout << char(number[2]);}}
			}
				
			if(bet22 == false){rnd_bet14++;} if(bet25 == false){rnd_bet14++;} if(bet30 == false){rnd_bet14++;}
		
			cout << "\n" + spaces2+ underline + smoothline1 + underline + smoothline1 + underline + "\n"
			<< spaces2+ spaces1 + smoothline1 + spaces1 + "|\n"
			<< spaces2+ spaces0 ;
	}


//number 4 in the table
	void num4 (){
		if(bet14 == false){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout << char(number[3]);
			setConsoleColor(7);bet32 = false;}
			
		if(bet19 == false){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout << char(number[3]);
			setConsoleColor(7);bet32 = false;}

		if(bet23 == false){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout << char(number[3]);
			setConsoleColor(7);bet32 = false;}

		if(bet27 == false){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout << char(number[3]);
			setConsoleColor(7);bet32 = false;}
			
		if (number[3] == 4){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[3] ; 
			setConsoleColor(7);bet32 = false;}
			
			if(bet16 == true){if (number[3] != 4){cout << char(number[3]);}}
			if(bet14 == false){if(bet14 == true){if (number[3] != 4){cout << char(number[3]);}}}
			if(bet19 == false){if(bet19 == true){if (number[3] != 4){cout << char(number[3]);}}}
			if(bet23 == false){if(bet23 == true){if (number[3] != 4){cout << char(number[3]);}}}			
			if(bet27 == false){if(bet27 == true){if (number[3] != 4){cout << char(number[3]);}}}
			
			if (bet14 == true && bet19 == true && bet23 == true && bet27 == true){
			if(bet16 == false){if (number[3] != 4){cout << char(number[3]);}}
			}
						
			if(bet27 == false){rnd_bet14++;}
			
			cout <<  smoothline2 ;
	}

//number 5 in the table
	void num5 (){
		if(bet15 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet19 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}

		if(bet21 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet22 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet24 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet27 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}

		if(bet29 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}

		if(bet30 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[4]);
		setConsoleColor(7);bet32 = false;}
						
		if (number[4] == 5){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[4] ; 
			setConsoleColor(7);bet32 = false;}
			
			if(bet16 == true){if (number[4] != 5){cout << char(number[4]);}}
			if(bet15 == false){if(bet15 == true){if (number[4] != 5){cout << char(number[4]);}}}
			if(bet19 == false){if(bet19 == true){if (number[4] != 5){cout << char(number[4]);}}}
			if(bet21 == false){if(bet21 == true){if (number[4] != 5){cout << char(number[4]);}}}
			if(bet22 == false){if(bet22 == true){if (number[4] != 5){cout << char(number[4]);}}}				
			if(bet24 == false){if(bet24 == true){if (number[4] != 5){cout << char(number[4]);}}}			
			if(bet27 == false){if(bet27 == true){if (number[4] != 5){cout << char(number[4]);}}}
			if(bet29 == false){if(bet29 == true){if (number[4] != 5){cout << char(number[4]);}}}
			if(bet30 == false){if(bet30 == true){if (number[4] != 5){cout << char(number[4]);}}}

			if (bet15 == true && bet19 == true && bet21 == true && bet22 == true && bet24 == true && bet27 == true &&
			bet29 == true && bet30 == true){
				if(bet16 == false){if (number[4] != 5){cout << char(number[4]);}}
			}
					
			cout << smoothline2 ;
	}

//number 6 in the table
	void num6 (){
		if(bet17 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[5]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet19 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[5]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet25 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[5]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet27 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[5]);
		setConsoleColor(7);bet32 = false;}
		
		if (number[5] == 6){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[5] ; 
			setConsoleColor(7);bet32 = false;}
		
			if(bet16 == true){if (number[5] != 6){cout << char(number[5]);}}
			if(bet17 == false){if(bet17 == true){if (number[5] != 6){cout << char(number[5]);}}}
			if(bet19 == false){if(bet19 == true){if (number[5] != 6){cout << char(number[5]);}}}
			if(bet25 == false){if(bet25 == true){if (number[5] != 6){cout << char(number[5]);}}}
			if(bet27 == false){if(bet27 == true){if (number[5] != 6){cout << char(number[5]);}}}

			if (bet17 == true && bet19 == true && bet25 == true && bet27 == true){
				if(bet16 == false){if (number[5] != 6){cout << char(number[5]);}}
			}
	
			cout << "\n" + spaces2 + underline + smoothline1 + underline + smoothline1 + underline + "\n"
			<< spaces2+ spaces1 + smoothline1 + spaces1 + "|\n"
			<< spaces2+ spaces0 ;
	}

//number 7 in the table
	void num7 (){
		if(bet14 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[6]);
		setConsoleColor(7);bet32 = false;}

		if(bet20 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[6]);
		setConsoleColor(7);bet32 = false;}

		if(bet22 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[6]);
		setConsoleColor(7);bet32 = false;}

		if(bet23 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[6]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet28 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[6]);
		setConsoleColor(7);bet32 = false;}

		if(bet30 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[6]);
		setConsoleColor(7);bet32 = false;}
								
		if (number[6] == 7){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[6] ; 
			setConsoleColor(7);}
			
			if(bet16 == true){if (number[6] != 7){cout << char(number[6]);}}
			if(bet14 == false){if(bet14 == true){if (number[6] != 7){cout << char(number[6]);}}}
			if(bet20 == false){if(bet20 == true){if (number[6] != 7){cout << char(number[6]);}}}
			if(bet22 == false){if(bet22 == true){if (number[6] != 7){cout << char(number[6]);}}}			
			if(bet23 == false){if(bet23 == true){if (number[6] != 7){cout << char(number[6]);}}}	
			if(bet28 == false){if(bet28 == true){if (number[6] != 7){cout << char(number[6]);}}}				
			if(bet30 == false){if(bet30 == true){if (number[6] != 7){cout << char(number[6]);}}}

			if (bet14 == true && bet20 == true && bet22 == true && bet23 == true && bet28 == true && bet30 == true){
				if(bet16 == false){if (number[6] != 7){cout << char(number[6]);}}
			}
											
		if(bet20 == false){rnd_bet14++;} if(bet28 == false){rnd_bet14++;}
		
			cout << smoothline2 ;
	}

//number 8 in the table
	void num8 (){
		if(bet15 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[7]);
		setConsoleColor(7);bet32 = false;}

		if(bet20 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[7]);
		setConsoleColor(7);bet32 = false;}

		if(bet24 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[7]);
		setConsoleColor(7);bet32 = false;}
		
		if(bet28 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[7]);
		setConsoleColor(7);bet32 = false;}
		
		if (number[7] == 8){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[7]; 
			setConsoleColor(7);bet32 = false;}
			
			if(bet16 == true){if (number[7] != 8){cout << char(number[7]);}}
			if(bet15 == false){if(bet15 == true){if (number[7] != 8){cout << char(number[7]);}}}
			if(bet20 == false){if(bet20 == true){if (number[7] != 8){cout << char(number[7]);}}}
			if(bet24 == false){if(bet24 == true){if (number[7] != 8){cout << char(number[7]);}}}
			if(bet28 == false){if(bet28 == true){if (number[7] != 8){cout << char(number[7]);}}}

			if (bet15 == true && bet20 == true && bet24 == true && bet28 == true){
				if(bet16 == false){if (number[7] != 8){cout << char(number[7]);}}
			}
										
			cout << smoothline2 ;
	}

//number 9 in the table
	void num9 (){
		if(bet17 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[8]);
		setConsoleColor(7);bet32 = false;}
	
		if(bet20 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[8]);
		setConsoleColor(7);bet32 = false;}

		if(bet21 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[8]);
		setConsoleColor(7);bet32 = false;}	
		
		if(bet25 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[8]);
		setConsoleColor(7);bet32 = false;}	
	
		if(bet28 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[8]);
		setConsoleColor(7);bet32 = false;}	

		if(bet29 == false){
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout << char(number[8]);
		setConsoleColor(7);bet32 = false;}
					
		if (number[8] == 9){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout << number[8] ; 
			setConsoleColor(7);}
			
			if(bet16 == true){if (number[8] != 9){cout << char(number[8]);}}
			if(bet17 == false){if(bet17 == true){if (number[8] != 9){cout << char(number[8]);}}}
			if(bet20 == false){if(bet20 == true){if (number[8] != 9){cout << char(number[8]);}}}		
			if(bet21 == false){if(bet21 == true){if (number[8] != 9){cout << char(number[8]);}}}
			if(bet25 == false){if(bet25 == true){if (number[8] != 9){cout << char(number[8]);}}}						
			if(bet28 == false){if(bet28 == true){if (number[8] != 9){cout << char(number[8]);}}}
			if(bet29 == false){if(bet29 == true){if (number[8] != 9){cout << char(number[8]);}}}

			if (bet17 == true && bet20 == true && bet21 == true && bet25 == true && bet28 == true && bet29 == true){
				if(bet16 == false){if (number[8] != 9){cout << char(number[8]);}}
			}							
																
			cout << "\n" + spaces2+ spaces1 + smoothline1 + spaces1 + "|\n\n\n";
			
	}
	
//all numbers
	void all_numbers(){
		num1();
		num2();
		num3();
		num4();
		num5();
		num6();
		num7();
		num8();
		num9();
	}
	
		
//the first mode of the table
	void mode1_table (){
		if (number[0] != 1){number[0] = 1;}
		if (number[1] != 2){number[1] = 2;}
		if (number[2] != 3){number[2] = 3;}
		if (number[3] != 4){number[3] = 4;}
		if (number[4] != 5){number[4] = 5;}
		if (number[5] != 6){number[5] = 6;}
		if (number[6] != 7){number[6] = 7;}
		if (number[7] != 8){number[7] = 8;}
		if (number[8] != 9){number[8] = 9;}
	}

//player win1
	void player1_win () {
		string player_Win1 = name_player1 + " Win"; int text_time1 = 1;
		system ("color 2F");
		cout<<spaces2+spaces0+player_Win1;
		beat1();
		sleep(text_time1);
		mode1_table();
		range_counter1++;
		bet9 = false;
		rnd++;
	}	
	
//player win2
	void player2_win () {
		string player_Win2 = name_player2 + " Win"; int text_time1 = 1;
		system ("color 2F");
		cout<<spaces2+spaces0+player_Win2;
		beat1();
		sleep(text_time1);
		mode1_table ();
		range_counter2++;
		bet9 = false;
		rnd++;
	}

//restart the game	
	void restart (){
		if (bet12 == true){
			if(range_counter1  == restart_number || range_counter2  == restart_number){
			cout<<"  Do you want the game to start from the beginning 0-0 ? press (y / n) : ";
				cin >> yes_no;
			if (yes_no == 'y'){range_counter1 = 0 ; range_counter2 = 0 ; rnd++; bet10 = false;}
			else{ rnd++; bet11 = false; bet12 = false ; rnd_restart = 0 ;}}
		}
	}	

//the condition of being a winner
	void winning_bet(){
		if (number[0] == nut1 && number[3] == nut1 && number[6] == nut1){if (bet14 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[1] == nut1 && number[4] == nut1 && number[7] == nut1){if (bet15 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[2] == nut1 && number[5] == nut1 && number[8] == nut1){if (bet17 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[0] == nut1 && number[1] == nut1 && number[2] == nut1){if (bet18 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[3] == nut1 && number[4] == nut1 && number[5] == nut1){if (bet19 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[6] == nut1 && number[7] == nut1 && number[8] == nut1){if (bet20 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[0] == nut1 && number[4] == nut1 && number[8] == nut1){if (bet21 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[2] == nut1 && number[4] == nut1 && number[6] == nut1){if (bet22 == true){player1_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[0] == nut2 && number[3] == nut2 && number[6] == nut2){if (bet23 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[1] == nut2 && number[4] == nut2 && number[7] == nut2){if (bet24 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[2] == nut2 && number[5] == nut2 && number[8] == nut2){if (bet25 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[0] == nut2 && number[1] == nut2 && number[2] == nut2){if (bet26 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[3] == nut2 && number[4] == nut2 && number[5] == nut2){if (bet27 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[6] == nut2 && number[7] == nut2 && number[8] == nut2){if (bet28 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[0] == nut2 && number[4] == nut2 && number[8] == nut2){if (bet29 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
		if (number[2] == nut2 && number[4] == nut2 && number[6] == nut2){if (bet30 == true){player2_win();bet16 = true;}
		else{bet16 = false;}}
	}

//winning bet lights
	void winning_bet_lights(){
		if (number[0] == nut1 && number[3] == nut1 && number[6] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet14 = false;}}}
		if (number[1] == nut1 && number[4] == nut1 && number[7] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet15 = false;}}}
		if (number[2] == nut1 && number[5] == nut1 && number[8] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet17 = false;}}}
		if (number[0] == nut1 && number[1] == nut1 && number[2] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet18 = false;}}}
		if (number[3] == nut1 && number[4] == nut1 && number[5] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet19 = false;}}}
		if (number[6] == nut1 && number[7] == nut1 && number[8] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet20 = false;}}}
		if (number[0] == nut1 && number[4] == nut1 && number[8] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet21 = false;}}}
		if (number[2] == nut1 && number[4] == nut1 && number[6] == nut1){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet22 = false;}}}
		if (number[0] == nut2 && number[3] == nut2 && number[6] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet23 = false;}}}
		if (number[1] == nut2 && number[4] == nut2 && number[7] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet24 = false;}}}
		if (number[2] == nut2 && number[5] == nut2 && number[8] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet25 = false;}}}
		if (number[0] == nut2 && number[1] == nut2 && number[2] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet26 = false;}}}
		if (number[3] == nut2 && number[4] == nut2 && number[5] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet27 = false;}}}
		if (number[6] == nut2 && number[7] == nut2 && number[8] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet28 = false;}}}
		if (number[0] == nut2 && number[4] == nut2 && number[8] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet29 = false;}}}
		if (number[2] == nut2 && number[4] == nut2 && number[6] == nut2){if(rnd_bet14 % 2 == 0){if(bet16 == true){bet30 = false;}}}
	}
	
//condition to be equal	
	void equal_condition(){
		if (number[0] != 1 && number[1] != 2 && number[2] != 3 && number[3] != 4 &&
			number[4] != 5 && number[5] != 6 && number[6] != 7 && number[7] != 8 && number[8] != 9){
			bet13 = false;
			system ("color 47");
			cout<<spaces2+spaces0+" Nobody won";
			beat2();
			sleep(1);
			mode1_table();
			}
	}
	
//player
	void player (){
		if( rnd % 2 == 0){
			int input_player1;	cout<< spaces3 + "Pleyar 1 Enter a Number : ";
			cin >> input_player1 ;
					
				if (input_player1 > 9){cout<<message; sleep(text_time);}
				if (input_player1 < 1){cout<<message; sleep(text_time);}
				
		switch ( input_player1 ) {
			case 1 : if (number[0] != 1) {cout<<message; sleep(text_time); break;}
			else {number[0] = nut1 ; break;}
			case 2 : if (number[1] != 2) {cout<<message; sleep(text_time); break;}
			else {number[1] = nut1 ; break;}
			case 3 : if (number[2] != 3) {cout<<message; sleep(text_time); break;}
			else {number[2] = nut1 ; break;}
			case 4 : if (number[3] != 4) {cout<<message; sleep(text_time); break;}
			else {number[3] = nut1 ; break;}
			case 5 : if (number[4] != 5) {cout<<message; sleep(text_time); break;}
			else {number[4] = nut1 ; break;}
			case 6 : if (number[5] != 6) {cout<<message; sleep(text_time); break;}
			else {number[5] = nut1 ; break;}
			case 7 : if (number[6] != 7) {cout<<message; sleep(text_time); break;}
			else {number[6] = nut1 ; break;}
			case 8 : if (number[7] != 8) {cout<<message; sleep(text_time); break;}
			else {number[7] = nut1 ; break;}
			case 9 : if (number[8] != 9) {cout<<message; sleep(text_time); break;}
			else {number[8] = nut1 ; break;}
			}
		}
		
		else{
				
			int input_player2;	cout<< "\n\n" + spaces3 + "Pleyar 2 Enter a Number : ";
			cin >> input_player2 ;
				
				if (input_player2 > 9){cout<<message; sleep(text_time);}
				if (input_player2 < 1){cout<<message; sleep(text_time);}
				
		switch ( input_player2 ) {
			case 1 : if (number[0] != 1) {cout<<message; sleep(text_time); break;}
			else {number[0] = nut2 ; break;}
			case 2 : if (number[1] != 2) {cout<<message; sleep(text_time); break;}
			else {number[1] = nut2 ; break;}
			case 3 : if (number[2] != 3) {cout<<message; sleep(text_time); break;}
			else {number[2] = nut2 ; break;}
			case 4 : if (number[3] != 4) {cout<<message; sleep(text_time); break;}
			else {number[3] = nut2 ; break;}
			case 5 : if (number[4] != 5) {cout<<message; sleep(text_time); break;}
			else {number[4] = nut2 ; break;}
			case 6 : if (number[5] != 6) {cout<<message; sleep(text_time); break;}
			else {number[5] = nut2 ; break;}
			case 7 : if (number[6] != 7) {cout<<message; sleep(text_time); break;}
			else {number[6] = nut2 ; break;}
			case 8 : if (number[7] != 8) {cout<<message; sleep(text_time); break;}
			else {number[7] = nut2 ; break;}
			case 9 : if (number[8] != 9) {cout<<message; sleep(text_time); break;}
			else {number[8] = nut2 ; break;}
			}
		}
	
	}

//two player game functions	
	void two_player_game(){
		if(bet30 == false){bet30 = true; sleep(3);}
		if(bet29 == false){bet29 = true; sleep(3);}
		if(bet28 == false){bet28 = true; sleep(3);}
		if(bet27 == false){bet27 = true; sleep(3);}
		if(bet26 == false){bet26 = true; sleep(3);}
		if(bet25 == false){bet25 = true; sleep(3);}	
		if(bet24 == false){bet24 = true; sleep(3);}
		if(bet23 == false){bet23 = true; sleep(3);}
		if(bet22 == false){bet22 = true; sleep(3);}
		if(bet21 == false){bet21 = true; sleep(3);}
		if(bet20 == false){bet20 = true; sleep(3);}
		if(bet19 == false){bet19 = true; sleep(3);}
		if(bet18 == false){bet18 = true; sleep(3);}
		if(bet17 == false){bet17 = true; sleep(3);}
		if(bet15 == false){bet15 = true; sleep(3);}
		if(bet14 == false){bet14 = true; sleep(3);}
		if(bet30 == true){
		if(bet29 == true){
		if(bet28 == true){
		if(bet27 == true){	
		if(bet26 == true){	
		if(bet25 == true){
		if(bet24 == true){
		if(bet23 == true){
		if(bet22 == true){
		if(bet21 == true){
		if(bet20 == true){
    	if(bet19 == true){
		if(bet18 == true){
		if(bet17 == true){
		if(bet15 == true){
		if(bet14 == true){
		winning_bet_lights();
		restart();
		if(bet11 == true){
		if(bet10 == true){
       	winning_bet();
		if(bet30 == true){
		if(bet29 == true){
		if(bet28 == true){
		if(bet27 == true){	
		if(bet26 == true){    
		if(bet25 == true){
		if(bet24 == true){
    	if(bet23 == true){
	    if(bet22 == true){
	    if(bet21 == true){
    	if(bet20 == true){
    	if(bet19 == true){
		if(bet18 == true){
		if(bet17 == true){
		if(bet15 == true){
		if(bet14 == true){
		if(bet13 == true){
		if(bet9 == true){
		player();}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
		bet9 = true , bet10 = true , bet11 = true , bet13 = true; rnd++; 
	}
	
	
	
	
//Play with the computer
	
	void selection(){
		system("color 2F");
		cout<<"\n\n\n\n\n\n\n\n\n\t\t" ;
		cout<<"1. Two player game" ;
		cout<<"\t" ;
		cout<<"2. Play with the robot" ;
		cout<<"\n\n\n\n\n" + spaces1 + "\t\t\t" ; 
		cout<<"  Please select a number : ";
		cin>>game_selection;
		system("cls");
	}
	
	void game_level(){
		system("color 3F");
		cout<< "\n\n\n\n\n\n\n\n\n" + spaces2 + spaces0  ;
		cout<<" 1. Easy" ;
		cout<<"\n\n\n\n\n" + spaces1 + "\t\t\t" ; 
		cout<<" Please select your game level : ";
		cin>>level_selection;
		system("cls");
	}
	
//slide
	void slide (){
		system("color 02");
		cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
		spaces2 + spaces0 ;
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout<<" Tic Tac Toe \n\n\n\n";
		setConsoleColor(7);
		cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
		cout<<"  Hello,"; usleep(290000); 
		cout <<"welcome,";usleep(290000);
		cout <<"please choose "; usleep(290000);
		cout <<"your name \n\n\n\n";
		setConsoleColor(7);
	}
	
	void name (){
		cout<<"\n\n\n" + spaces3 ;
 		cout<<" Name Player 2 ( O ) : ";
		getline(cin,name_player2);
			
		while(bet0 == true || bet1 == true || bet2 == true || bet3 == true){
 			
 			for (int i = 0 ; i < name_player2.size() ; i++){
			
		if (name_player2[i] >= 'A' && name_player2[i] <= 'Z' || name_player2[i] >= 'a' || name_player2[i] >= 'z'  ||
			  name_player2[i] == ' '){bet0 = false;}
	
		else{
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Please use letters for your name !"; sleep(2);
			setConsoleColor(7);
			bet0 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			name();}
			
		if (name_player2[i] == ' '){error_spaces++;}
		}
		
		if (error_spaces > 1){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet1 = true;
			error_spaces = error_spaces - error_spaces ;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			name();}	
		else{bet1 = false; error_spaces = error_spaces - error_spaces ;}
		
		if (name_player2.length() <= 2){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet2 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			name();}
		else{bet2 = false;}
				
		if(name_player2.length() > 16){
			setConsoleColor(FOREGROUND_RED | FOREGROUND_RED | FOREGROUND_RED );
			cout<<"\n" + spaces5 ;
			cout<<"Your name is less than three letters !"; sleep(2);
			setConsoleColor(7);
			bet3 = true;
			system("cls");
			system("color 02");
			cout<<"\n  ___________________________________________________________________________\n\n\n\n" + 
			spaces2 + spaces0 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
			cout<<" Tic Tac Toe \n\n\n\n";
			setConsoleColor(7);
			cout <<spaces1 + spaces1 + spaces1 + spaces1 ;
			setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_RED | BACKGROUND_RED | BACKGROUND_RED );
			cout<<"  Hello,"; 
			cout <<"welcome,";
			cout <<"please choose ";
			cout <<"your name \n\n\n\n";
			setConsoleColor(7);
			name();}
		else{bet3 = false;}
		}
	}
	
	void line1(){
		cout<<"\n\n\n\n\n  ___________________________________________________________________________";
		sleep(1);
		system("cls");
	}
	
//Tic Tac Toe table
	void table1 (){
		system("color 0F");
	
		cout<<"\n\n";
	
		cout<< spaces2 + spaces0 ;
		setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE |  BACKGROUND_GREEN | BACKGROUND_GREEN | BACKGROUND_GREEN );
		cout<< " Tic Tac Toe \n\n\n";
		setConsoleColor(7);
		cout<< spaces1 + spaces0 + "Robot" + spaces4 + spaces0 << name_player2 + "\n\n"
		<< spaces1 + "player 1 ( X )" + spaces3 + spaces1 + spaces1 + " player 2 ( O ) " + "\n\n"
		<< spaces0 + "Player Win Counter 1 = " << range_counter1	
		<< spaces3 + "Player Win Counter 2 = " << range_counter2 << "\n" 
		<< spaces2+ spaces1 + smoothline1 + spaces1 + "|\n"
		<< spaces2+ spaces0 ;
	}

//player
	void player_bot (){
		if( rnd % 2 == 0){
					if(rnd_bot == 0){
					if(number[0] == 1){number[0] = 'X'; sleep(1);}}
					
					if(rnd_bot == 1){
					if(number[1] == 2){number[1] = 'X'; sleep(1);}
					if(number[1] != 2){
					if(number[2] == 3){number[2] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 2){
					if(number[2] == 3){number[2] = 'X'; sleep(1);}
					if(number[2] != 3){if(number[3] == 4){number[3] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 3){
					if(number[3] == 4){number[3] = 'X'; sleep(1);}
					if(number[3] != 4){if(number[4] == 5){number[4] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 4){
					if(number[4] == 5){number[4] = 'X'; sleep(1);}
					if(number[4] != 5){if(number[5] == 6){number[5] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 5){
					if(number[5] == 6){number[5] = 'X'; sleep(1);}
					if(number[5] != 6){if(number[6] == 7){number[6] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 6){
					if(number[6] == 7){number[6] = 'X'; sleep(1);}
					if(number[6] != 7){if(number[7] == 8){number[7] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 7){
					if(number[7] == 8){number[7] = 'X'; sleep(1);}
					if(number[7] != 8){if(number[8] == 9){number[8] = 'X'; sleep(1);}}}
					
					if(rnd_bot == 8){
					if(number[8] == 9){number[8] = 'X'; sleep(1);}
					if(number[8] != 9){if(number[2] == 9){number[2] = 'X'; sleep(1);}}}
					rnd_bot++;
			}
		else{
			int input_player2;	cout<< spaces3 + "\tEnter a Number : ";
			cin >> input_player2 ;
					
				if (input_player2 > 9){cout<<message; sleep(text_time);}
				if (input_player2 < 1){cout<<message; sleep(text_time);}
				
		switch ( input_player2 ) {
			case 1 : if (number[0] != 1) {cout<<message; sleep(text_time); break;}
			else {number[0] = nut2 ; break;}
			case 2 : if (number[1] != 2) {cout<<message; sleep(text_time); break;}
			else {number[1] = nut2 ; break;}
			case 3 : if (number[2] != 3) {cout<<message; sleep(text_time); break;}
			else {number[2] = nut2 ; break;}
			case 4 : if (number[3] != 4) {cout<<message; sleep(text_time); break;}
			else {number[3] = nut2 ; break;}
			case 5 : if (number[4] != 5) {cout<<message; sleep(text_time); break;}
			else {number[4] = nut2 ; break;}
			case 6 : if (number[5] != 6) {cout<<message; sleep(text_time); break;}
			else {number[5] = nut2 ; break;}
			case 7 : if (number[6] != 7) {cout<<message; sleep(text_time); break;}
			else {number[6] = nut2 ; break;}
			case 8 : if (number[7] != 8) {cout<<message; sleep(text_time); break;}
			else {number[7] = nut2 ; break;}
			case 9 : if (number[8] != 9) {cout<<message; sleep(text_time); break;}
			else {number[8] = nut2 ; break;}
			}
		}	
//		switch ( input_player2 ) {
//			case 1 : if (number[0] != 1) {cout<<message; sleep(text_time); break;}
//			else {number[0] = nut2 ; break;}
//			case 2 : if (number[1] != 2) {cout<<message; sleep(text_time); break;}
//			else {number[1] = nut2 ; break;}
//			case 3 : if (number[2] != 3) {cout<<message; sleep(text_time); break;}
//			else {number[2] = nut2 ; break;}
//			case 4 : if (number[3] != 4) {cout<<message; sleep(text_time); break;}
//			else {number[3] = nut2 ; break;}
//			case 5 : if (number[4] != 5) {cout<<message; sleep(text_time); break;}
//			else {number[4] = nut2 ; break;}
//			case 6 : if (number[5] != 6) {cout<<message; sleep(text_time); break;}
//			else {number[5] = nut2 ; break;}
//			case 7 : if (number[6] != 7) {cout<<message; sleep(text_time); break;}
//			else {number[6] = nut2 ; break;}
//			case 8 : if (number[7] != 8) {cout<<message; sleep(text_time); break;}
//			else {number[7] = nut2 ; break;}
//			case 9 : if (number[8] != 9) {cout<<message; sleep(text_time); break;}
//			else {number[8] = nut2 ; break;}
//			}
	}
	
	void two_player_game1(){
		if(bet30 == false){bet30 = true; sleep(3);}
		if(bet29 == false){bet29 = true; sleep(3);}
		if(bet28 == false){bet28 = true; sleep(3);}
		if(bet27 == false){bet27 = true; sleep(3);}
		if(bet26 == false){bet26 = true; sleep(3);}
		if(bet25 == false){bet25 = true; sleep(3);}	
		if(bet24 == false){bet24 = true; sleep(3);}
		if(bet23 == false){bet23 = true; sleep(3);}
		if(bet22 == false){bet22 = true; sleep(3);}
		if(bet21 == false){bet21 = true; sleep(3);}
		if(bet20 == false){bet20 = true; sleep(3);}
		if(bet19 == false){bet19 = true; sleep(3);}
		if(bet18 == false){bet18 = true; sleep(3);}
		if(bet17 == false){bet17 = true; sleep(3);}
		if(bet15 == false){bet15 = true; sleep(3);}
		if(bet14 == false){bet14 = true; sleep(3);}
		if(bet30 == true){
		if(bet29 == true){
		if(bet28 == true){
		if(bet27 == true){	
		if(bet26 == true){	
		if(bet25 == true){
		if(bet24 == true){
		if(bet23 == true){
		if(bet22 == true){
		if(bet21 == true){
		if(bet20 == true){
    	if(bet19 == true){
		if(bet18 == true){
		if(bet17 == true){
		if(bet15 == true){
		if(bet14 == true){
		winning_bet_lights();
		restart();
		if(bet11 == true){
		if(bet10 == true){
       	winning_bet();
		if(bet30 == true){
		if(bet29 == true){
		if(bet28 == true){
		if(bet27 == true){	
		if(bet26 == true){    
		if(bet25 == true){
		if(bet24 == true){
    	if(bet23 == true){
	    if(bet22 == true){
	    if(bet21 == true){
    	if(bet20 == true){
    	if(bet19 == true){
		if(bet18 == true){
		if(bet17 == true){
		if(bet15 == true){
		if(bet14 == true){
		if(bet13 == true){
		if(bet9 == true){
		player_bot();}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
		bet9 = true , bet10 = true , bet11 = true , bet13 = true; rnd++; 
	}

int main (){

		selection();
	if(game_selection == 2){
		game_level();
	if(level_selection == 1){
		slide();
		name();}
		line1();
	while (true){
		table();
		num1();
		num2();
		num3();
		num4();
		num5();
		num6();
		num7();
		num8();
		num9();
	two_player_game1();
		system("cls");}}
	if(game_selection == 1){
		slide_one();
		nam1();
		nam2();
		line();
	while (true){
		table();
		all_numbers();
		two_player_game();
		system("cls");}
	}
}
